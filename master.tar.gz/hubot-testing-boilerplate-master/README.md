# hubot-testing-boilerplate

This is a starter set of tests for Github's Hubot.

For more information about writing tests for Hubot, check out my blog post about [Testing Hubot Scripts][testing_hubot_scripts].

[testing_hubot_scripts]: https://amussey.github.io/2015/08/11/testing-hubot-scripts

## Running Tests

After cloning this repo, two commands are required to get the tests running:

```bash
npm install   # Install the required dependencies.
npm run test  # Run the test script, as defined in package.json
```
